# **User Guide:**

*This document should detail each Function's inputs and outputs and give examples of their Pre and Post Processing Scripts*

**NOTE:** Once you have finished development, you can automatically generate this document by using `docgen`:
```
$ resilient-sdk docgen -p <path_to_package>
OR
$ resilient-sdk docgen -p <path_to_package> --only-user-guide
```